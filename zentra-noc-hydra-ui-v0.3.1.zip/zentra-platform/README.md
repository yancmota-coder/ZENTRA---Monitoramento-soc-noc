# ZENTRA NOC v0.3.0 — integração real, sem dados fictícios

Esta versão remove os conjuntos de dados demonstrativos. O dashboard só apresenta inventário, problemas e indicadores quando a API consulta o Zabbix com sucesso. Quando a integração falha, a interface informa a indisponibilidade e não substitui os dados por exemplos.

## Arquitetura

Navegador → React/Vite → FastAPI → Zabbix JSON-RPC API.

O Wazuh está identificado como não configurado/adaptador pendente; a área SOC não fabrica eventos. A topologia lista apenas hosts conhecidos pelo Zabbix e não inventa enlaces.

## Requisitos

- Python 3.11+
- Node.js 20+
- Zabbix Server com API JSON-RPC acessível pela VM do ZENTRA
- Usuário técnico de leitura ou token de API

## 1. Configure o Zabbix

No Zabbix, crie um usuário técnico com permissões somente de leitura para os grupos de hosts que o ZENTRA deve consultar. Prefira um token de API, se suportado pela versão instalada.

Copie `backend/.env.example` para `backend/.env` e configure:

```env
APP_ENV=production
CORS_ORIGINS=http://192.168.56.10:5173
ZABBIX_URL=https://SEU-ZABBIX/api_jsonrpc.php
ZABBIX_TOKEN=SEU_TOKEN
ZABBIX_VERIFY_TLS=true
```

Se usar usuário/senha em vez de token, deixe `ZABBIX_TOKEN` vazio e preencha `ZABBIX_USER` e `ZABBIX_PASSWORD`. Não use a conta administrativa. Não publique o `.env` nem compartilhe tokens.

## 2. Inicie a API

```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env  # somente se ainda não existir; depois edite .env
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

Valide `http://192.168.56.10:8000/api/health` e `http://192.168.56.10:8000/docs`. O campo `zabbix` deve retornar `online`.

## 3. Inicie o dashboard

```bash
cd frontend
npm install
cp .env.example .env
# ajuste VITE_API_BASE_URL para o IP/DNS real da API
npm run build
npm run dev -- --host 0.0.0.0
```

Acesse `http://192.168.56.10:5173`.

## Endpoints

- `GET /api/health`
- `GET /api/overview`
- `GET /api/hosts`
- `GET /api/hosts/{hostid}/metrics`
- `GET /api/problems`
- `GET /api/incidents`
- `GET /api/security`
- `GET /api/topology`
- `GET /api/reports/summary`
- `GET /api/settings`

## Limites conhecidos desta etapa

- CPU/RAM/disco dependem dos itens existentes e habilitados em cada host; se um item não existir, a API retorna `null` e o dashboard mostra N/D.
- O endpoint de métricas apresenta o último valor coletado, não um histórico. O histórico será implementado consultando `history.get`/`trend.get` de acordo com o tipo dos itens.
- A integração SOC/Wazuh ainda precisa ser ligada à versão instalada e validada. Não há eventos de segurança artificiais.
- A topologia não descobre camada 2/3; só exibe o inventário real do Zabbix.
- Esta versão é somente leitura. Ações de reconhecimento/fechamento de eventos e RBAC exigem autenticação e trilha de auditoria antes de serem habilitadas.
